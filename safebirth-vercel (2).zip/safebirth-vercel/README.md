# SafeBirth — Persiapan Persalinan

SafeBirth adalah aplikasi web responsif berbahasa Indonesia dengan tema pink pastel untuk membantu persiapan kelahiran: kalkulator HPL lintas tahun, rundown menuju HPL, skrining tanda bahaya, edukasi tanda persalinan, checklist tas, rencana kesiapan ibu, catatan kontraksi, dan riwayat lokal.

## Kalkulator HPL untuk tahun berjalan dan masa mendatang
- Input HPHT tidak diberi batas tahun maksimum tetap; tanggal dalam tahun berjalan maupun tahun-tahun mendatang dapat dipilih pada kalender perangkat.
- Rumus Naegele standar: tambah 7 hari, kurangi 3 bulan, lalu tambah 1 tahun. Untuk HPHT Januari–Maret, penyesuaian yang setara adalah menambahkan 9 bulan tanpa menambah tahun.
- Konstruksi tanggal memakai normalisasi kalender bawaan JavaScript agar pergantian bulan, tahun, dan hari ke-29/30/31 konsisten lintas browser. Tanggal yang overflow diteruskan ke bulan berikutnya, tidak dipotong ke hari terakhir bulan. Cache service worker diperbarui agar versi lama terganti setelah deploy. Contoh uji: HPHT 1 Januari 2026 menghasilkan HPL 8 Oktober 2026; HPHT 1 April 2026 menghasilkan HPL 8 Januari 2027; HPHT 24 Mei 2026 menghasilkan HPL 3 Maret 2027 sesuai operasi kalender (31 Februari diteruskan ke Maret, bukan dipotong menjadi 28 Februari).
- HPHT masa depan tetap bisa dihitung sebagai simulasi matematis, dengan label yang membedakannya dari usia kehamilan aktual.
- HPL adalah estimasi berbasis asumsi siklus sekitar 28 hari. Konfirmasikan HPL dengan bidan/dokter, khususnya bila siklus tidak teratur atau HPHT tidak pasti.

## Deploy ke Vercel
1. Unggah seluruh isi folder ini ke repository GitHub atau siapkan folder proyek lokal.
2. Di Vercel pilih **Add New → Project**, lalu impor repository tersebut.
3. Untuk proyek statis HTML, pilih **Other**, kosongkan Build Command, dan gunakan root folder yang berisi `index.html`.
4. Deploy lalu buka URL HTTPS dari Vercel.
5. Android: buka di Chrome dan pilih **Install app** atau **Add to Home screen**. iPhone/iPad: buka URL dengan Safari → **Bagikan** → **Tambahkan ke Layar Utama**. Laptop: buka URL menggunakan browser modern.

## Coba secara lokal
Buka `index.html` untuk fitur dasar. Instalasi PWA dan cache offline memerlukan HTTPS atau localhost.

## Riwayat dan privasi
- HPL, checklist, rencana persalinan, dan riwayat disimpan lokal menggunakan `localStorage` pada browser/perangkat tersebut.
- Tidak ada sinkronisasi otomatis antardevice. Gunakan tombol ekspor/impor JSON untuk memindahkan cadangan.
- Riwayat dapat hilang jika data browser dihapus atau jika menggunakan mode privat/incognito.

## Catatan keselamatan
Aplikasi ini untuk edukasi, bukan diagnosis. Pendarahan, dugaan ketuban pecah, kejang, gerakan janin berkurang/tidak terasa, demam tinggi, atau sakit kepala sangat hebat perlu penilaian medis segera. Hubungi fasilitas kesehatan atau layanan darurat setempat; jangan menunda pertolongan untuk menggunakan aplikasi.
